// Your web app's Firebase configuration
export const firebaseConfig = {
	apiKey: "AIzaSyBMBzuHpzs8nrhbD7zg8AH4Z0rNPtg1y-g",
	authDomain: "contest-a2d5c.firebaseapp.com",
	projectId: "contest-a2d5c",
	storageBucket: "contest-a2d5c.appspot.com",
	messagingSenderId: "228098169786",
	appId: "1:228098169786:web:e6c2ffbd5d81e3bf7fdb83"
}