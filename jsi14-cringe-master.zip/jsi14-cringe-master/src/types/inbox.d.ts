declare interface InboxMessage {
	content: string,
	alreadyRead: boolean,
	id: string
}